# app-backend

## Overview

The backend of the Hospital Management System is responsible for managing and processing data related to the day-to-day activities of the hospital. It provides APIs for the frontend to interact with, and handles tasks such as user authentication, patient record management, and appointment scheduling.
