package hospital.backend.exceptions;

public class DoctorException extends RuntimeException {
	public DoctorException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
