package hospital.backend.exceptions;

public class InvalidAuthorityException extends Exception {

	public InvalidAuthorityException() {
		super("Invality Authority Found");
		// TODO Auto-generated constructor stub
	}

}
