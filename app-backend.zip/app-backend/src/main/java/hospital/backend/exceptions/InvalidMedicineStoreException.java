package hospital.backend.exceptions;

public class InvalidMedicineStoreException extends Exception {
public InvalidMedicineStoreException()
{
	System.out.println("invalid medicine");
}
}
