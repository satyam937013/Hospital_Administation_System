package hospital.backend.exceptions;

public class MedicineStoreNotFoundException extends Exception {
	public MedicineStoreNotFoundException() {
		super("Medicine Not found");
		// TODO Auto-generated constructor stub
	}

	
}

