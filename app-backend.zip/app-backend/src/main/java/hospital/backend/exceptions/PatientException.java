package hospital.backend.exceptions;

public class PatientException extends RuntimeException {
	public PatientException(String msg) {
		super(msg);
	}

}
