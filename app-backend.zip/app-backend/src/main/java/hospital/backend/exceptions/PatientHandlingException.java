package hospital.backend.exceptions;

public class PatientHandlingException extends RuntimeException {
	public PatientHandlingException(String msg) {
		super(msg);
	}

}
