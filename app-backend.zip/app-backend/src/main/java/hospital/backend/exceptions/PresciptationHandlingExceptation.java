package hospital.backend.exceptions;

public class PresciptationHandlingExceptation extends RuntimeException{

	public PresciptationHandlingExceptation(String message) {
		super(message);
	}
}
