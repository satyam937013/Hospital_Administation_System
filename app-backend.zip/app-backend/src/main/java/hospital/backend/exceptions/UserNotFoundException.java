package hospital.backend.exceptions;

public class UserNotFoundException extends Exception {

	public UserNotFoundException() {
		super("User Not found");
		// TODO Auto-generated constructor stub
	}

	
}
