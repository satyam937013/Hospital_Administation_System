import React from 'react';

const ErrorPage = () => {
  return (
    <div className="container mt-5 alert alert-danger" role="alert">
      Error Occured
    </div>
  );
};

export default ErrorPage;