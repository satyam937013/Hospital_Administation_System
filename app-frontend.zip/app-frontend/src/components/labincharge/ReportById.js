import React from 'react'

const ReportById = () => {
  return (
    <div>ReportById</div>
  )
}

export default ReportById